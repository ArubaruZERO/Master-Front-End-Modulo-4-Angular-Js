import { Directive } from './.directive';

describe('Directive', () => {
  it('should create an instance', () => {
    const directive = new Directive();
    expect(directive).toBeTruthy();
  });
});
