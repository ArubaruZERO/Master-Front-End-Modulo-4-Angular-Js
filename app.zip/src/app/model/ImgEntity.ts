export interface ImgListEntity {
  id: number,
  src: String,
  title: String,
}
