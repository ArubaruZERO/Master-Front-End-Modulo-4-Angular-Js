export interface LoginEntity {
  user: string;
  password: string;
}
