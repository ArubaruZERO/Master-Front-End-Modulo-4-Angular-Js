import { ZoomDirective } from './zoom.directive';

describe('ZoomDirective', () => {
  it('should create an instance', () => {
    const directive = new ZoomDirective();
    expect(directive).toBeTruthy();
  });
});
