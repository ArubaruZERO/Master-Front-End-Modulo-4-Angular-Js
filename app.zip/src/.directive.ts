import { Directive } from '@angular/core';

@Directive({
  selector: '[app]'
})
export class Directive {

  constructor() { }

}
